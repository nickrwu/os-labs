pwd; ls; mkdir class; ls; cd class; ls; pwd; cd ..; pwd
